## Matchmaker site

You are going to build this website from a comp, just like a real front-end developer would do. I've started you off with some boilerplate HTML and CSS to get this going but the rest is up to you.

![Design Goal](StartupMatchmaker.png)

Break into groups of 3-4 people and develop this site collaboratively.

This is the most advanced website you have built to date. Use all the skills I've been teaching you - think about semantic HTML, use a DOM tree, think about layout methods BEFORE you build and incorporate custom features where you feel they are necessary.

Remember: there are many ways to build this site and there aren't strictly wrong or right answers. Do your best and work in groups - this is how front-end developers get things done.
